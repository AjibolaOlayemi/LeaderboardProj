package com.example.leaderboard;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.widget.ViewPager2;


import android.os.Build;
import android.os.Bundle;
import android.view.View;


import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {

    private TabLayout mTabLayout;
    private ViewPager ViewPager;


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tablayout);
//        tabLayout.addTab(tabLayout.newTab().setText("Learning Leaders"));
//        tabLayout.addTab(tabLayout.newTab().setText("Skill Iq Leaders"));
//        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        final ViewPager viewPager = (ViewPager) findViewById(R.id.pager);
        final PagerAdapter adapter = new PagerAdapter
                () {
            @Override
            public int getCount() {
                return 0;
            }

            @Override
            public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
                return false;
            }
        };
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));




        //ViewPager2 viewPager = (ViewPager2) findViewById(R.id.pager);



//        tabLayout.setupWithViewPager(ViewPager);

    }


////    private void addTabs(ViewPager2 viewPager) {
////        ViewPagerAdapter adapter = new ViewPagerAdapter (getSupportFragmentManager());
////        adapter.addFrag (new LearningLeadersFragment(), "LEARNING LEADERS");
////        adapter.addFrag (new SkillIqLeadersFragment(), "SKILL IQ LEADERS");
////        viewPager.setAdapter(adapter);
//    }



}
package com.example.leaderboard;

import com.example.leaderboard.LearningLeadersFragment;
import com.example.leaderboard.SkillIqLeadersFragment;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

//package com.example.leaderboard;
//
//import android.os.Bundle;
//import android.view.View;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import androidx.annotation.NonNull;
//import androidx.fragment.app.Fragment;
//import androidx.fragment.app.FragmentActivity;
//import androidx.fragment.app.FragmentManager;
//import androidx.fragment.app.FragmentPagerAdapter;
//import androidx.viewpager.widget.PagerAdapter;
//import androidx.viewpager2.adapter.FragmentStateAdapter;
//import androidx.viewpager2.widget.ViewPager2;
//
class PagerAdapter extends FragmentStatePagerAdapter {

    int mNumOfTabs;
    public PagerAdapter(FragmentManager fm, int NumOfTabs){
        super(fm);
        this.mNumOfTabs = NumOfTabs;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position){
            case 0:
                LearningLeadersFragment learningLeadersFragment= new LearningLeadersFragment();
                return learningLeadersFragment;

            case 1:
                SkillIqLeadersFragment skillIqLeadersFragment = new SkillIqLeadersFragment();
                return skillIqLeadersFragment;

            default:
                return null;

        }
    }

    @Override
    public int getCount() {
        return mNumOfTabs;
    }
}
//    private static final int NUM_PAGES = 2;
//    private ViewPager2 mPager2;
//    private PagerAdapter mPagerAdapter;
//
//    @Override
//    protected void onCreate (Bundle savedInstanceState){
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.fragment_learning_leaders);
//
//        mPager2 = (ViewPager2) findViewById(R.id.viewpager);
//        mPagerAdapter = new PagerAdapter(getSupportFragmentManager());
//        mPager2.setAdapter(mPagerAdapter);
//    }
//
//    public ViewPagerAdapter(@NonNull FragmentManager manager) {
//        super(manager);
//    }
//
//
//    public void addFrag(Fragment fragment, String title){
//        mFragmentList.add(fragment);
//        mFragmentTitleList.add(title);
//    }
//
//    @Override
//    public CharSequence getPageTitle (int position){
//        return mFragmentTitleList.get(position);
//    }
//
//    @NonNull
//    @Override
//    public Fragment createFragment(int position) {
//        return null;
//    }
//
//    @Override
//    public int getItemCount() {
//        return 0;
//    }
//}
